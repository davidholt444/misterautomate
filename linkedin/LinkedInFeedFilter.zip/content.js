// LinkedIn Feed Filter — content.js v2.0
// Hides promoted posts, job updates, and suggested posts.
// Settings controlled via popup toggles, persisted in chrome.storage.sync.
// Hides the outer occludable-update wrapper — Ember internals untouched.

(function () {
  'use strict';

  // ─── STATE ─────────────────────────────────────────────────────────────────

  const DEFAULTS = { promoted: true, jobUpdates: false, suggested: false, jobsRecommended: false, recommended: false };
  let settings = { ...DEFAULTS };

  // Track hidden containers per category so we can unhide them on toggle
  const hidden = {
    promoted:        new Map(), // container el → true
    jobUpdates:      new Map(),
    suggested:       new Map(),
    jobsRecommended: new Map(),
    recommended:     new Map(),
  };

  // ─── COUNTER CARD ──────────────────────────────────────────────────────────
  // Compact card pinned to the right edge, vertically centered.

  const CATEGORY_META = {
    promoted:        { icon: '🚫', label: 'Ads' },
    jobUpdates:      { icon: '💼', label: 'Job updates' },
    suggested:       { icon: '👤', label: 'Suggested' },
    jobsRecommended: { icon: '📋', label: 'Job widgets' },
    recommended:     { icon: '✨', label: 'Recommended' },
  };

  const card = document.createElement('div');
  Object.assign(card.style, {
    position:       'fixed',
    top:            '50%',
    right:          '0',
    transform:      'translateY(-50%)',
    zIndex:         '2147483647',
    background:     'rgba(10, 8, 22, 0.88)',
    border:         '1px solid rgba(124,58,237,0.45)',
    borderRight:    'none',
    borderRadius:   '10px 0 0 10px',
    padding:        '10px 14px 10px 12px',
    fontFamily:     'monospace',
    fontSize:       '11px',
    color:          '#e2e8f0',
    display:        'none',
    userSelect:     'none',
    pointerEvents:  'none',
    backdropFilter: 'blur(8px)',
    boxShadow:      '-3px 0 18px rgba(124,58,237,0.25)',
    lineHeight:     '1.6',
  });
  document.body.appendChild(card);

  function updatePill() {
    const keys = Object.keys(hidden);
    const total = keys.reduce((n, k) => n + hidden[k].size, 0);
    if (total === 0) { card.style.display = 'none'; return; }

    while (card.firstChild) card.removeChild(card.firstChild);

    // Total line
    const tot = document.createElement('div');
    Object.assign(tot.style, {
      color: '#a78bfa', fontWeight: 'bold', fontSize: '12px',
      paddingBottom: '6px', marginBottom: '6px',
      borderBottom: '1px solid rgba(124,58,237,0.2)',
      whiteSpace: 'nowrap',
    });
    tot.textContent = `🚫 ${total} hidden`;
    card.appendChild(tot);

    // One row per active category
    keys.forEach(key => {
      const count = hidden[key].size;
      if (!count) return;
      const { icon, label } = CATEGORY_META[key];
      const row = document.createElement('div');
      Object.assign(row.style, {
        display: 'flex', justifyContent: 'space-between',
        gap: '12px', whiteSpace: 'nowrap', alignItems: 'center',
      });
      const lbl = document.createElement('span');
      lbl.style.color = '#64748b';
      lbl.textContent = `${icon} ${label}`;
      const num = document.createElement('span');
      num.style.color = '#7c3aed';
      num.style.fontWeight = 'bold';
      num.textContent = count;
      row.appendChild(lbl);
      row.appendChild(num);
      card.appendChild(row);
    });

    card.style.display = 'block';
  }

  // ─── HIDE / SHOW HELPERS ───────────────────────────────────────────────────

  function hideContainer(container, category) {
    if (hidden[category].has(container)) return;
    hidden[category].set(container, true);
    container.style.setProperty('display', 'none', 'important');
    updatePill();
  }

  function showCategory(category) {
    hidden[category].forEach((_, container) => {
      container.style.removeProperty('display');
    });
    hidden[category].clear();
    updatePill();
  }

  // ─── FIND OUTER WRAPPER ────────────────────────────────────────────────────

  function getOccludableWrapper(el) {
    let node = el;
    let fallback = null;
    for (let i = 0; i < 20; i++) {
      node = node.parentElement;
      if (!node) break;
      // Best: the outer virtual-scroll wrapper
      if (node.classList.contains('occludable-update')) return node;
      // Good fallback: a feed card container
      if (!fallback && (
        node.classList.contains('feed-shared-update-v2') ||
        node.classList.contains('artdeco-card') ||
        node.tagName === 'LI' ||
        node.tagName === 'SECTION'
      )) fallback = node;
    }
    return fallback;
  }

  // ─── DETECTION ─────────────────────────────────────────────────────────────

  function detectAndHide() {
    // ── Promoted posts ──────────────────────────────────────────────────────
    if (settings.promoted) {
      // Third-party sponsored posts ("Promoted" / "Promoted by X" / "Ad")
      document.querySelectorAll('span').forEach(span => {
        const t = span.textContent.trim();
        if (!t.startsWith('Promoted') && t !== 'Ad') return;
        const wrapper = getOccludableWrapper(span);
        if (wrapper) hideContainer(wrapper, 'promoted');
      });

      // LinkedIn Premium upsell cards ("Try for free" / "Try Premium for $0" / "Try 1 month for $0")
      document.querySelectorAll('button, a, span').forEach(btn => {
        const t = btn.textContent.trim();
        if (t !== 'Try for free' && t !== 'Try Premium for $0' && !/^Try \d+ month/.test(t)) return;
        const wrapper = getOccludableWrapper(btn);
        if (wrapper) hideContainer(wrapper, 'promoted');
      });

      // LinkedIn Premium upsell cards by heading text
      document.querySelectorAll('p, span, h2, h3').forEach(el => {
        if (el.textContent.trim() !== 'Grow professionally with Premium') return;
        const wrapper = getOccludableWrapper(el);
        if (wrapper) hideContainer(wrapper, 'promoted');
      });

      // Sidebar iframe ads — the "Ad" label lives inside an iframe so text search
      // can't reach it. Target the container section directly.
      document.querySelectorAll('section.ad-banner-container').forEach(section => {
        hideContainer(section, 'promoted');
      });
    }

    // ── Job updates ─────────────────────────────────────────────────────────
    // Matches: "X's job update", "X has a new job", etc.
    if (settings.jobUpdates) {
      document.querySelectorAll('span, a').forEach(el => {
        if (/\bjob update\b/i.test(el.textContent.trim())) {
          const wrapper = getOccludableWrapper(el);
          if (wrapper) hideContainer(wrapper, 'jobUpdates');
        }
      });
    }

    // ── Suggested posts ─────────────────────────────────────────────────────
    // Matches the "Suggested" label that appears instead of a timestamp
    if (settings.suggested) {
      document.querySelectorAll('span').forEach(span => {
        if (span.textContent.trim() !== 'Suggested') return;
        const wrapper = getOccludableWrapper(span);
        if (wrapper) hideContainer(wrapper, 'suggested');
      });
    }

    // ── Jobs recommended for you ────────────────────────────────────────────
    if (settings.jobsRecommended) {
      document.querySelectorAll('h2, h3, span, p').forEach(el => {
        if (el.textContent.trim() !== 'Jobs recommended for you') return;
        const wrapper = getOccludableWrapper(el);
        if (wrapper) hideContainer(wrapper, 'jobsRecommended');
      });
    }

    // ── Recommended for you ─────────────────────────────────────────────────
    // Matches the "Recommended for you" people-to-follow widget
    if (settings.recommended) {
      document.querySelectorAll('h2, h3, span, p').forEach(el => {
        if (el.textContent.trim() !== 'Recommended for you') return;
        const wrapper = getOccludableWrapper(el);
        if (wrapper) hideContainer(wrapper, 'recommended');
      });
    }
  }

  // ─── APPLY SETTINGS ────────────────────────────────────────────────────────

  function applySettings(newSettings) {
    const prev = { ...settings };
    settings = { ...settings, ...newSettings };

    // For each category that was just turned OFF, unhide those containers
    if (prev.promoted        && !settings.promoted)        showCategory('promoted');
    if (prev.jobUpdates      && !settings.jobUpdates)      showCategory('jobUpdates');
    if (prev.suggested       && !settings.suggested)       showCategory('suggested');
    if (prev.jobsRecommended && !settings.jobsRecommended) showCategory('jobsRecommended');
    if (prev.recommended     && !settings.recommended)     showCategory('recommended');

    // Re-scan to pick up anything newly enabled
    detectAndHide();
  }

  // ─── MUTATION OBSERVER ─────────────────────────────────────────────────────

  function watchFeed() {
    const feed = document.querySelector('.scaffold-finite-scroll__content') ||
                 document.querySelector('main') || document.body;

    new MutationObserver(detectAndHide).observe(feed, { childList: true, subtree: true });
  }

  // ─── MESSAGE LISTENER ──────────────────────────────────────────────────────
  // Receives live setting changes from popup.js

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SETTINGS_CHANGED') {
      applySettings(msg.settings);
    }
  });

  // ─── INIT ──────────────────────────────────────────────────────────────────

  chrome.storage.sync.get(DEFAULTS, (saved) => {
    settings = { ...DEFAULTS, ...saved };
    detectAndHide();
    watchFeed();
    console.log('[Feed Filter] Running with settings:', settings);
  });

})();
