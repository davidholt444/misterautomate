// popup.js — reads and writes settings via chrome.storage.sync

const DEFAULTS = {
  promoted:         true,
  jobUpdates:       false,
  suggested:        false,
  jobsRecommended:  false,
  recommended:      false,
};

const toggleIds = ['promoted', 'jobUpdates', 'suggested', 'jobsRecommended', 'recommended'];

// Load saved settings and apply to UI
chrome.storage.sync.get(DEFAULTS, (settings) => {
  toggleIds.forEach(key => {
    const el = document.getElementById(`toggle-${key}`);
    if (el) el.checked = !!settings[key];
  });
});

// Save on any toggle change, send message to content script
toggleIds.forEach(key => {
  const el = document.getElementById(`toggle-${key}`);
  if (!el) return;

  el.addEventListener('change', () => {
    const update = { [key]: el.checked };
    chrome.storage.sync.set(update);

    // Notify the active LinkedIn tab to update immediately
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'SETTINGS_CHANGED', settings: update })
          .catch(() => {}); // ignore if tab isn't on LinkedIn
      }
    });
  });
});
